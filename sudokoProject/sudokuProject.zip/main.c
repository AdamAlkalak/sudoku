#include "defenitions.h"

void main()
{
	createActivePlayersList();
}